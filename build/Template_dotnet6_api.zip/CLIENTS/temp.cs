﻿namespace $safeprojectname$.Clients
{
    public class temp
    {
    }
}
